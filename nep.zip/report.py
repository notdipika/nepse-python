"""
NEPSE Daily Market Report Generator
------------------------------------
• 10 banks/stocks, one company per page
• Stats table (OHLC / Day Change / Volume / Polls)
• Descriptive statistics table (Count/Mean/Std/Min/25%/50%/75%/Max)
• Line chart + volume bar chart from historical data
• Day Summary, Volume, Circuit Breaker interpretations
• Fixed title spacing
"""

import pandas as pd
import matplotlib
import pathlib as path
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np
import io, os

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame,
    Paragraph, Spacer, Table, TableStyle,
    HRFlowable, Image, PageBreak,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER

PAGE_W, PAGE_H = A4
L_MAR = R_MAR = 18 * mm
T_MAR = 16 * mm
B_MAR = 14 * mm
FOOTER_H = 8 * mm
USABLE_W = PAGE_W - L_MAR - R_MAR   # ~474 pt

# ─────────────────────────────────────────────────────────────────────────────
#  Colors
# ─────────────────────────────────────────────────────────────────────────────
C_BLUE   = colors.HexColor("#1A3E72")
C_RED    = colors.HexColor("#D9292E")
C_GREEN  = colors.HexColor("#1B8A4E")
C_DGRAY  = colors.HexColor("#444444")
C_MGRAY  = colors.HexColor("#888888")
C_LGRAY  = colors.HexColor("#F4F6FA")
C_ALTROW = colors.HexColor("#EEF2F8")
C_WHITE  = colors.white
C_BORDER = colors.HexColor("#CCCCCC")

# ─────────────────────────────────────────────────────────────────────────────
#  Load & prepare historical data  (cleaned.csv — 25 Mar session)
# ─────────────────────────────────────────────────────────────────────────────
def generate_all_charts(df):
    df_hist = df.copy()
    df_hist["fetched_at"] = pd.to_datetime(df_hist["fetched_at"])
    df_hist.sort_values("fetched_at", inplace=True)


def sym_hist(sym):
    return df_hist[df_hist["symbol"] == sym].copy()


def sym_last(sym, col):
    s = sym_hist(sym)
    return float(s.iloc[-1][col]) if len(s) else 0.0


def sym_agg(sym):
    s = sym_hist(sym)
    if s.empty:
        return {}
    return dict(
        open       = float(s.iloc[0]["open"]),
        high       = float(s["high"].max()),
        low        = float(s["low"].min()),
        close      = float(s.iloc[-1]["close"]),
        prev_close = float(s.iloc[0]["prev_close"]),
        volume     = int(s["volume"].sum()),
        pct        = float(s.iloc[-1]["pct_change_calc"]),
        ma5        = float(s.iloc[-1]["ma5"]),
        ma10       = float(s.iloc[-1]["ma10"]),
        ma20       = float(s.iloc[-1]["ma20"]),
    )


# ─────────────────────────────────────────────────────────────────────────────
#  Auto-generate interpretation text
# ─────────────────────────────────────────────────────────────────────────────
def interpret(sym, d):
    o, h, l, c   = d["open"], d["high"], d["low"], d["close"]
    prev, vol, pct = d["prev_close"], d["volume"], d["pct"]
    chg = round(c - prev, 2)
    direction = "up" if chg >= 0 else "down"

    if direction == "down":
        trend = ("fell early in the session then recovered toward close"
                 if c > (o + l) / 2
                 else "drifted lower through the session")
    else:
        trend = ("rose early then gave back some gains toward close"
                 if c < (o + h) / 2
                 else "moved gradually higher through the session")

    summary = (
        f"{sym} opened at NPR {o:,.2f} and closed at NPR {c:,.2f}, "
        f"{'lost' if chg < 0 else 'gained'} NPR {abs(chg):.2f} "
        f"({abs(pct):.2f}%) on the day. The stock {trend}. "
        f"It reached its intraday high of NPR {h:,.2f} "
        f"and its low of NPR {l:,.2f} during the session."
    )

    vol_comment = (
        f"Total volume recorded was {vol:,} shares. "
        + ("Volume was high today, indicating strong trader interest."
           if vol > 100_000
           else "Volume was light today, suggesting limited activity.")
    )

    d.update(change=chg, direction=direction, circuit=False,
             summary=summary, vol_comment=vol_comment)
    return d


# ─────────────────────────────────────────────────────────────────────────────
#  TODAY_DATA  (5 actuals from March 26 PDF  +  5 from cleaned.csv)
# ─────────────────────────────────────────────────────────────────────────────
TODAY_DATA = {}

pdf_actuals = {
    "ADBL":  dict(open=333.20, high=340.00, low=328.50, close=329.50,
                  prev_close=333.20, volume=107842, pct=1.11,
                  ma5=sym_last("ADBL","ma5"), ma10=sym_last("ADBL","ma10"), ma20=sym_last("ADBL","ma20")),
    "NABIL": dict(open=541.00, high=548.00, low=538.00, close=540.00,
                  prev_close=541.00, volume=121279, pct=0.18,
                  ma5=sym_last("NABIL","ma5"), ma10=sym_last("NABIL","ma10"), ma20=sym_last("NABIL","ma20")),
    "NICA":  dict(open=396.40, high=404.90, low=387.00, close=399.20,
                  prev_close=396.40, volume=472601, pct=0.71,
                  ma5=sym_last("NICA","ma5"), ma10=sym_last("NICA","ma10"), ma20=sym_last("NICA","ma20")),
    "NTC":   dict(open=902.20, high=932.00, low=895.00, close=899.80,
                  prev_close=902.20, volume=16492, pct=0.27,
                  ma5=sym_last("NTC","ma5"), ma10=sym_last("NTC","ma10"), ma20=sym_last("NTC","ma20")),
    "SCB":   dict(open=677.00, high=693.60, low=676.00, close=675.80,
                  prev_close=677.00, volume=25941, pct=0.18,
                  ma5=sym_last("SCB","ma5"), ma10=sym_last("SCB","ma10"), ma20=sym_last("SCB","ma20")),
}
for sym, d in pdf_actuals.items():
    TODAY_DATA[sym] = interpret(sym, d)

for sym in ["EBL", "GBIME", "SBL", "UPPER", "NEPSE"]:
    d = sym_agg(sym)
    if d:
        TODAY_DATA[sym] = interpret(sym, d)

# ─────────────────────────────────────────────────────────────────────────────
#  Styles
# ─────────────────────────────────────────────────────────────────────────────
def build_styles():
    ST = getSampleStyleSheet()
    ST.add(ParagraphStyle("ReportTitle",
        fontName="Helvetica-Bold", fontSize=22, textColor=C_BLUE,
        alignment=TA_CENTER, leading=26, spaceBefore=0, spaceAfter=0))
    ST.add(ParagraphStyle("ReportSubtitle",
        fontName="Helvetica", fontSize=10, textColor=C_MGRAY,
        alignment=TA_CENTER, leading=14, spaceBefore=0, spaceAfter=0))
    ST.add(ParagraphStyle("SymbolHeader",
        fontName="Helvetica-Bold", fontSize=17, textColor=C_BLUE,
        spaceBefore=0, spaceAfter=0, leading=22))
    ST.add(ParagraphStyle("SectionHead",
        fontName="Helvetica-Bold", fontSize=9.5, textColor=C_BLUE,
        spaceBefore=0, spaceAfter=0, leading=14))
    ST.add(ParagraphStyle("Body",
        fontName="Helvetica", fontSize=8.5, textColor=C_DGRAY,
        leading=13, spaceBefore=0, spaceAfter=0))
    ST.add(ParagraphStyle("FooterStyle",
        fontName="Helvetica", fontSize=7, textColor=C_MGRAY,
        alignment=TA_CENTER))
    return ST


# ─────────────────────────────────────────────────────────────────────────────
#  Stats table  (Open / High / Low / Last Close / Day Change / Volume / Polls)
# ─────────────────────────────────────────────────────────────────────────────
def build_stats_table(info, ST):
    chg   = info["change"]
    pct   = info["pct"]
    arrow = "▲" if chg >= 0 else "▼"
    c_hex = "#1B8A4E" if chg >= 0 else "#D9292E"
    chg_s = f"{arrow} {abs(chg):.2f} ({abs(pct):.2f}%)"

    def npr(v):
        return f"NPR {v:,.2f}"

    headers = ["Open", "High", "Low", "Last Close", "Day Change", "Volume", "Polls"]
    vals    = [
        npr(info["open"]), npr(info["high"]), npr(info["low"]), npr(info["close"]),
        Paragraph(f'<font color="{c_hex}"><b>{chg_s}</b></font>', ST["Body"]),
        f"{info['volume']:,}", "6",
    ]

    col_w = [62, 62, 62, 78, 92, 70, 48]   # total = 474

    data = [
        [Paragraph(f'<b><font color="white">{h}</font></b>', ST["Body"]) for h in headers],
        vals,
    ]
    tbl = Table(data, colWidths=col_w)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_BLUE),
        ("BACKGROUND",    (0,1), (-1,1), C_LGRAY),
        ("FONTNAME",      (0,1), (-1,1), "Helvetica-Bold"),
        ("FONTSIZE",      (0,0), (-1,-1), 8),
        ("ALIGN",         (0,0), (-1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("BOX",           (0,0), (-1,-1), 0.5, C_BORDER),
        ("INNERGRID",     (0,0), (-1,-1), 0.3, C_BORDER),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
        ("RIGHTPADDING",  (0,0), (-1,-1), 4),
    ]))
    return tbl


# ─────────────────────────────────────────────────────────────────────────────
#  Descriptive stats table  (Count / Mean / Std Dev / Min / 25% / 50% / 75% / Max)
# ─────────────────────────────────────────────────────────────────────────────
def build_desc_table(sym, ST):
    s = sym_hist(sym)
    if s.empty:
        return None

    c = s["close"].values
    stat_keys = ["Count", "Mean", "Std Dev", "Min", "25%", "Median", "75%", "Max"]
    stat_vals = [
        str(len(c)),
        f"{np.mean(c):,.2f}",
        f"{np.std(c):,.2f}",
        f"{np.min(c):,.2f}",
        f"{np.percentile(c,25):,.2f}",
        f"{np.percentile(c,50):,.2f}",
        f"{np.percentile(c,75):,.2f}",
        f"{np.max(c):,.2f}",
    ]

    cw = [USABLE_W / len(stat_keys)] * len(stat_keys)
    data = [
        [Paragraph(f'<b><font color="white">{k}</font></b>', ST["Body"]) for k in stat_keys],
        stat_vals,
    ]
    tbl = Table(data, colWidths=cw)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_BLUE),
        ("BACKGROUND",    (0,1), (-1,1), C_ALTROW),
        ("FONTNAME",      (0,1), (-1,1), "Helvetica"),
        ("FONTSIZE",      (0,0), (-1,-1), 7.5),
        ("ALIGN",         (0,0), (-1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("BOX",           (0,0), (-1,-1), 0.4, C_BORDER),
        ("INNERGRID",     (0,0), (-1,-1), 0.25, C_BORDER),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LEFTPADDING",   (0,0), (-1,-1), 3),
        ("RIGHTPADDING",  (0,0), (-1,-1), 3),
    ]))
    return tbl


# ─────────────────────────────────────────────────────────────────────────────
#  Chart  — close-price line  +  volume bars
# ─────────────────────────────────────────────────────────────────────────────
def make_chart(sym, info):
    s      = sym_hist(sym)
    is_up  = info["direction"] == "up"
    lc     = "#1B8A4E" if is_up else "#D9292E"
    fc     = "#1B8A4E18" if is_up else "#D9292E18"
    bc     = "#1B8A4E60" if is_up else "#D9292E60"

    fig, (ax1, ax2) = plt.subplots(
        2, 1, figsize=(7.2, 2.9),
        gridspec_kw={"height_ratios": [3, 1], "hspace": 0.06},
    )
    fig.patch.set_alpha(0)

    if not s.empty:
        x     = np.arange(len(s))
        close = s["close"].values
        vols  = s["volume"].values

        ax1.plot(x, close, color=lc, linewidth=1.7, zorder=3)
        ax1.fill_between(x, close.min() * 0.9995, close, color=fc)
        ax1.annotate(
            f"{close[-1]:,.1f}",
            xy=(x[-1], close[-1]), xytext=(5, 0),
            textcoords="offset points",
            fontsize=7, color=lc, fontweight="bold", va="center",
        )
        ax2.bar(x, vols, color=bc, width=0.8)
        ax2.set_xlim(-0.5, len(x) - 0.5)
        ax2.yaxis.set_major_formatter(
            FuncFormatter(lambda v, _: f"{int(v/1000)}K" if v >= 1000 else str(int(v))))
    else:
        ax2.set_visible(False)

    for ax in (ax1, ax2):
        ax.set_facecolor("none")
        ax.tick_params(labelsize=6, colors="#777777")
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
        ax.spines["left"].set_color("#CCCCCC")
        ax.spines["bottom"].set_color("#CCCCCC")

    ax1.set_xticks([])
    ax1.yaxis.set_major_formatter(FuncFormatter(lambda v, _: f"{v:,.0f}"))
    ax1.set_ylabel("Close Price (NPR)", fontsize=6, color="#888888", labelpad=3)
    ax2.set_xlabel("Session ticks  (25 Mar 2026)", fontsize=6, color="#888888", labelpad=2)
    ax2.set_ylabel("Volume", fontsize=6, color="#888888", labelpad=3)

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=160, bbox_inches="tight",
                facecolor="none", transparent=True)
    plt.close(fig)
    buf.seek(0)
    return buf


# ─────────────────────────────────────────────────────────────────────────────
#  Footer drawn on every page
# ─────────────────────────────────────────────────────────────────────────────
def on_page(canv, doc):
    canv.saveState()
    canv.setFont("Helvetica", 7)
    canv.setFillColor(C_MGRAY)
    canv.drawCentredString(
        PAGE_W / 2, FOOTER_H / 2,
        "Data sourced from merolagani.com  ·  For personal use only  ·  "
        "Report generated Thursday, 26 March 2026 at 08:42 NPT",
    )
    canv.restoreState()


# ─────────────────────────────────────────────────────────────────────────────
#  Summary table — all companies on one final page
# ─────────────────────────────────────────────────────────────────────────────
def build_summary_table(data, ST):
    headers = ["Symbol", "Open", "High", "Low", "Last Close", "Day Change", "Volume"]
    col_w   = [52, 62, 62, 62, 72, 104, 60]   # total = 474

    rows = [
        [Paragraph(f'<b><font color="white">{h}</font></b>', ST["Body"]) for h in headers]
    ]
    for sym, info in data.items():
        chg   = info["change"]
        pct   = info["pct"]
        arrow = "▲" if chg >= 0 else "▼"
        c_hex = "#1B8A4E" if chg >= 0 else "#D9292E"
        chg_s = f"{arrow} {abs(chg):.2f} ({abs(pct):.2f}%)"
        rows.append([
            Paragraph(f'<b>{sym}</b>', ST["Body"]),
            f"NPR {info['open']:,.2f}",
            f"NPR {info['high']:,.2f}",
            f"NPR {info['low']:,.2f}",
            f"NPR {info['close']:,.2f}",
            Paragraph(f'<font color="{c_hex}"><b>{chg_s}</b></font>', ST["Body"]),
            f"{info['volume']:,}",
        ])

    tbl = Table(rows, colWidths=col_w, repeatRows=1)
    style_cmds = [
        # Header
        ("BACKGROUND",    (0, 0), (-1, 0), C_BLUE),
        ("FONTSIZE",      (0, 0), (-1, -1), 8),
        ("ALIGN",         (0, 0), (-1, -1), "CENTER"),
        ("ALIGN",         (0, 1), (0, -1),  "LEFT"),   # symbol left-aligned
        ("VALIGN",        (0, 0), (-1, -1), "MIDDLE"),
        ("BOX",           (0, 0), (-1, -1), 0.5, C_BORDER),
        ("INNERGRID",     (0, 0), (-1, -1), 0.3, C_BORDER),
        ("TOPPADDING",    (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING",   (0, 0), (-1, -1), 5),
        ("RIGHTPADDING",  (0, 0), (-1, -1), 4),
        ("FONTNAME",      (0, 1), (0, -1),  "Helvetica-Bold"),
        ("TEXTCOLOR",     (0, 1), (-1, -1), C_DGRAY),
    ]
    # Alternating row backgrounds
    for i in range(1, len(rows)):
        bg = C_LGRAY if i % 2 == 1 else C_ALTROW
        style_cmds.append(("BACKGROUND", (0, i), (-1, i), bg))

    tbl.setStyle(TableStyle(style_cmds))
    return tbl


# ─────────────────────────────────────────────────────────────────────────────
#  Assemble document
# ─────────────────────────────────────────────────────────────────────────────


OUT = path("reports/nepse_report.pdf")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

doc = BaseDocTemplate(
    OUT, pagesize=A4,
    leftMargin=L_MAR, rightMargin=R_MAR,
    topMargin=T_MAR,  bottomMargin=B_MAR + FOOTER_H,
)
frame = Frame(
    L_MAR, B_MAR + FOOTER_H,
    USABLE_W, PAGE_H - T_MAR - B_MAR - FOOTER_H,
    id="main",
)
doc.addPageTemplates([PageTemplate(id="all", frames=[frame], onPage=on_page)])

ST   = build_styles()
story = []
syms  = list(TODAY_DATA.keys())
GAP   = 4 * mm

def company_section(sym, info, include_title=False):
    """Return a list of flowables for one company.
    If include_title=True, prepend the report masthead above the company name.
    """
    block = []

    if include_title:
        # ── Masthead (title + subtitle + thick rule) ──────────────────────────
        block.append(Spacer(1, 3*mm))
        block.append(Paragraph("NEPSE Daily Market Report", ST["ReportTitle"]))
        block.append(Spacer(1, 4*mm))
        block.append(Paragraph(
            "Thursday, 26 March 2026  ·  Generated 08:42 NPT",
            ST["ReportSubtitle"]))
        block.append(Spacer(1, 5*mm))
        block.append(HRFlowable(width="100%", thickness=1.5, color=C_BLUE))
        block.append(Spacer(1, 6*mm))

    # ── Company heading ───────────────────────────────────────────────────────
    block.append(Paragraph(sym, ST["SymbolHeader"]))
    block.append(Spacer(1, GAP))
    block.append(HRFlowable(width="100%", thickness=0.5, color=C_BORDER))
    block.append(Spacer(1, GAP))

    # ── OHLC stats table ──────────────────────────────────────────────────────
    block.append(build_stats_table(info, ST))
    block.append(Spacer(1, GAP + 1*mm))

    # ── Chart ─────────────────────────────────────────────────────────────────
    buf = make_chart(sym, info)
    # Slightly shorter chart height when title shares the page
    ch = 170 if include_title else 195
    block.append(Image(buf, width=USABLE_W, height=ch))
    block.append(Spacer(1, GAP))

    # ── Day Summary ───────────────────────────────────────────────────────────
    block.append(Paragraph("Day Summary", ST["SectionHead"]))
    block.append(Spacer(1, 1.5*mm))
    block.append(HRFlowable(width="100%", thickness=0.3, color=C_BORDER))
    block.append(Spacer(1, 1.5*mm))
    block.append(Paragraph(info["summary"], ST["Body"]))
    block.append(Spacer(1, GAP))

    # ── Volume ────────────────────────────────────────────────────────────────
    block.append(Paragraph("Volume", ST["SectionHead"]))
    block.append(Spacer(1, 1.5*mm))
    block.append(HRFlowable(width="100%", thickness=0.3, color=C_BORDER))
    block.append(Spacer(1, 1.5*mm))
    block.append(Paragraph(info["vol_comment"], ST["Body"]))
    block.append(Spacer(1, GAP))

    # ── Descriptive stats table ───────────────────────────────────────────────
    desc = build_desc_table(sym, ST)
    if desc:
        block.append(Paragraph(
            "Descriptive Statistics  (Close Price — Session Ticks)",
            ST["SectionHead"]))
        block.append(Spacer(1, 1.5*mm))
        block.append(HRFlowable(width="100%", thickness=0.3, color=C_BORDER))
        block.append(Spacer(1, 1.5*mm))
        block.append(desc)
        block.append(Spacer(1, GAP))

    # ── Circuit Breaker ───────────────────────────────────────────────────────
    block.append(Paragraph("Circuit Breaker", ST["SectionHead"]))
    block.append(Spacer(1, 1.5*mm))
    block.append(HRFlowable(width="100%", thickness=0.3, color=C_BORDER))
    block.append(Spacer(1, 1.5*mm))
    block.append(Paragraph("No circuit breaker was triggered.", ST["Body"]))

    return block


# ── Page 1: title + first company ────────────────────────────────────────────
story.extend(company_section(syms[0], TODAY_DATA[syms[0]], include_title=True))

# ── Pages 2–10: remaining companies, one per page ────────────────────────────
for sym in syms[1:]:
    story.append(PageBreak())
    story.extend(company_section(sym, TODAY_DATA[sym], include_title=False))

# ── Final page: all-company summary table ────────────────────────────────────
story.append(PageBreak())
story.append(Spacer(1, 3*mm))
story.append(Paragraph("Market Summary  —  All Companies", ST["ReportTitle"]))
story.append(Spacer(1, 4*mm))
story.append(Paragraph(
    "Thursday, 26 March 2026  ·  Generated 08:42 NPT",
    ST["ReportSubtitle"]))
story.append(Spacer(1, 5*mm))
story.append(HRFlowable(width="100%", thickness=1.5, color=C_BLUE))
story.append(Spacer(1, 7*mm))
story.append(build_summary_table(TODAY_DATA, ST))

doc.build(story)
print(f"Saved → {OUT}")


def build_pdf_report(df):
    global df_hist
    df_hist = df.copy()
    df_hist["fetched_at"] = pd.to_datetime(df_hist["fetched_at"])
    df_hist.sort_values("fetched_at", inplace=True)

    OUT = path("reports/nepse_report.pdf")
    OUT.parent.mkdir(parents=True, exist_ok=True)

    doc = BaseDocTemplate(
        str(OUT), pagesize=A4,
        leftMargin=L_MAR, rightMargin=R_MAR,
        topMargin=T_MAR,  bottomMargin=B_MAR + FOOTER_H,
    )

    frame = Frame(
        L_MAR, B_MAR + FOOTER_H,
        USABLE_W, PAGE_H - T_MAR - B_MAR - FOOTER_H,
        id="main",
    )

    doc.addPageTemplates([PageTemplate(id="all", frames=[frame], onPage=on_page)])

    ST = build_styles()
    story = []

    syms = list(TODAY_DATA.keys())
    GAP = 4 * mm

    # Page 1
    story.extend(company_section(syms[0], TODAY_DATA[syms[0]], include_title=True))

    # Remaining pages
    for sym in syms[1:]:
        story.append(PageBreak())
        story.extend(company_section(sym, TODAY_DATA[sym]))

    # Summary page
    story.append(PageBreak())
    story.append(Paragraph("Market Summary — All Companies", ST["ReportTitle"]))
    story.append(Spacer(1, 6 * mm))
    story.append(build_summary_table(TODAY_DATA, ST))

    doc.build(story)

    return OUT
